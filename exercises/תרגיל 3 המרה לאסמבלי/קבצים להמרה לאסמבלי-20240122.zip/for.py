x = int(input())
c = 1

for i in range(1, x+1):
    c = c*i

print(c)