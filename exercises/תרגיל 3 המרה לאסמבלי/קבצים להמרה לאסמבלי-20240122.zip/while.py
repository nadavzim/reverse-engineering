# while True
num1 = int(input())
num2 = int(input())

adder = 0
counter = 0
while True:
    adder += num2
    counter += 1
    if adder >= num1:
        break

print(counter)
