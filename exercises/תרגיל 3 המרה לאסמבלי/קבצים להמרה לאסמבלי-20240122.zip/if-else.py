num1 = int(input())

if num1 % 2 == 0:
    print(num1)
else:
    print(num1+1)