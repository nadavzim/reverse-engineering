a = int(input())
b = int(input())

if a < b:
    a ^= b
    b ^= a
    a ^= b

result = 0
for i in range(1, a + b + 1):
    for j in range(1, a - b + 1):
        result += i * j
print(result)

