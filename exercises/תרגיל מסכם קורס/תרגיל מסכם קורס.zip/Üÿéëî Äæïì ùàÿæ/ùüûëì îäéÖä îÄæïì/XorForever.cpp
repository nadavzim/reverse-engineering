// Source file: XorForever.cpp
#include "XorForever.h"
#include <iostream>
using namespace std;

extern "C" __declspec(dllexport) void XorForever() {
    string s = "", delusion = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    int target = 0x539, acc = 0;

    cout << "password: ";
    cin >> s;
    for (auto& i : s)
        acc += i;
    if (acc == target)
        cout << "http://bit.ly/3TwB99f";
}