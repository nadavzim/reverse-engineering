#pragma once
#ifdef final_assasment_reversing_dll_EXPORTS
#define final_assasment_reversing_dll_API __declspec(dllexport)
#else
#define final_assasment_reversing_dll_API __declspec(dllimport)

#endif // final_assasment_reversing_dll_EXPORTS
extern "C" final_assasment_reversing_dll_API void XorForever();


